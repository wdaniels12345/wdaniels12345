#include <stdio.h>
#include <iostream>
using namespace std;



const int mazeRows = 9;
const int mazeColumns = 9;
char maze[mazeRows][mazeColumns + 1] = {
    "x xxxxxxx",
    "x   x   x",
    "xxxxx x x",
    "x x   x x",
    "x x x xxx",
    "x   x x x",
    "x xxx x x",
    "x   x   x",
    "xxxxxxx x",
};

const char wall = 'x';
const char space= ' ';
const char user = '*';

class Coordinance
{
  public:
    int x, y;
    Coordinance(int _x = 0, int _y = 0)
    {
      x = _x;
      y = _y;
    }
    Coordinance(const Coordinance &coordinance)
    {
      x = coordinance.x;
      y = coordinance.y;
    }

};

Coordinance StartingPoint(1, 0);
Coordinance EndingPoint(7, 8);

void printMaze()
{
  for(int i=0; i < mazeRows; i++)
  cout << maze[i];
}


char get(int x, int y)
{
  if( x <= 0 || x >= mazeColumns || y <= 0 || y >= mazeRows)
  {
    return wall;
    return maze[y][x];
}
}

void set(int x, int y)
{
  if( x <= 0 || x >= mazeColumns || y <= 0 || y >= mazeRows)
    {
      return;
      maze[y][x];
    }
}

bool solve(int x, int y)
{
  //printMaze();
  //sleep(50);

  if (x == EndingPoint.x && y == EndingPoint.y) return true;
  if (get(x-1, y)  && solve(x-1, y)) return true;
  if (get(x+1, y)  && solve(x+1, y)) return true;
  if (get(x, y-1)  && solve(x, y-1)) return true;
  if (get(x, y+1)  && solve(x, y+1)) return true;

  set(x, y);
  //printMaze();
 // sleep(50);

  return false;
}


int main(int argc, char* argv[])
{
  if(solve(StartingPoint.x, StartingPoint.y))
  {
    printMaze();
    cout << "SOLVED!" << endl;
  }
  else
  {
    cout << "CANNOT SOLVE!" << endl;
  }
  return 0;
}

